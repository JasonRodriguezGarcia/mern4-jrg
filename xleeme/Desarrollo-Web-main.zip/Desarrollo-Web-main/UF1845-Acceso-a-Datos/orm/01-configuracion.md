# Object Relational Mapping (ORM)

https://www.youtube.com/watch?v=84-_5AIbabU

```bash
python -m venv .venv

# Activar el entorno virtual
# Mac
source .venv/bin/activate
# Windows
.\.venv\Scripts\activate.bat

# Upgrade
pip install --upgrade pip  # seguir las instrucciones en la consola
# Instalar bibliotecas
pip install sqlalchemy psycopg2-binary
```