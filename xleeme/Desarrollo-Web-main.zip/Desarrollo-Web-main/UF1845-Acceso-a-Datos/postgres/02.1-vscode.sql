SELECT version();
SELECT current_date;
SELECT current_time;
SELECT current_timestamp;

SELECT current_user;
SELECT current_database();


SELECT *
FROM information_schema.tables;

USE erp;

SELECT * FROM information_schema.tables;