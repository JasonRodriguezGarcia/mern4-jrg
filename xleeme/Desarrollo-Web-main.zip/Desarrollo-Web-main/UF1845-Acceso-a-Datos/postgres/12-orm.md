

python -m venv .venv


 source .venv/bin/activate
 o 
 .\.venv\Scripts\activate.bat

pip install --upgrade pip
pip install sqlalchemy psycopg2-binary