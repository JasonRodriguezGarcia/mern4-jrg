export const roles = {
  admin: ['read:any', 'write:any'],
  user: ['read:any'], // ['read:own'],  - sus recursos solamente
};
