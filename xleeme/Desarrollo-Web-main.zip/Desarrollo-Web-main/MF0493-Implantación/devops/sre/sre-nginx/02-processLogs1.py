with open("access.log", "r") as f:
    for line in f:
        print(line)
    