// cypress/support/commands.js
Cypress.Commands.add('login', (username, password) => {
  // custom login logic here
});