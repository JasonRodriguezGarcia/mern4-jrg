

| Tipo              | Ejemplo               | Característica principal                          |
|-------------------|------------------------|----------------------------------------------------|
| Permisiva         | MIT, BSD, Apache       | Libertad total, incluso para cerrar el código      |
| Copyleft          | GPL, AGPL              | Obliga a mantener el código libre                 |
| Propietaria       | Windows, Oracle        | No se permite ni ver ni modificar el código       |
| Source Available  | SSPL, Elastic License  | Se puede leer, pero no es software libre          |


# Actividad

Visitar https://github.com/trending y buscar algunos licencias