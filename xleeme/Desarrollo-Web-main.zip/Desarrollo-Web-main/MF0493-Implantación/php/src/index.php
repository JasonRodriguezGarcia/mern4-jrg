<?php
echo "Hello, World desde PHP!<br>";
?>