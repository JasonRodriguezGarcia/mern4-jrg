
# Comunicacion

Formas de comunicar snippets / fragmentos de código:
- https://carbon.now.sh/
- https://gist.github.com/



# Fin Ops

¿Qué es FinOps?
FinOps (abreviatura de Financial Operations) es una práctica que combina la gestión financiera con la operación y administración de recursos en la nube. Su objetivo principal es optimizar y controlar el gasto en servicios cloud, alineando los costos con el uso real y el valor para el negocio.

## Razón para FinOps

Control de costos en la nube:
A medida que las empresas migran a la nube, el gasto puede crecer rápidamente y volverse difícil de controlar. FinOps ayuda a monitorear, gestionar y optimizar esos gastos para evitar sorpresas.

Responsabilidad compartida:
FinOps promueve la **colaboración entre equipos técnicos (DevOps, ingeniería) y equipos financieros** para que ambos entiendan y controlen los costos en conjunto.

Visibilidad y transparencia:
Proporciona métricas claras y dashboards para que todas las partes interesadas tengan visibilidad sobre cómo se están consumiendo los recursos y cuánto cuestan.

Optimización continua:
Impulsa prácticas para ajustar recursos, eliminar desperdicios, usar reservas y descuentos, y negociar contratos más eficientes.

Alineación con el negocio:
Facilita que el gasto en tecnología cloud esté alineado con objetivos estratégicos y de negocio, maximizando el retorno de inversión.

## Historia de FinOps
Antes de la nube:
En infraestructuras tradicionales (on-premises), los costos eran más previsibles y fijos (hardware, licencias). La gestión financiera era más sencilla.

Aparición de la nube:
Con la adopción masiva de servicios cloud (AWS, Azure, Google Cloud) desde mediados de los 2010s, el modelo de pago por uso trajo flexibilidad pero también complejidad en la gestión de costos.

Nacimiento de FinOps (~2017):
Empresas grandes comenzaron a necesitar mejores prácticas para controlar gastos en la nube sin perder agilidad. En 2017 se fundó la FinOps Foundation, que definió principios y mejores prácticas para esta disciplina.

Crecimiento y adopción:
Desde entonces, FinOps se ha convertido en una práctica estándar para organizaciones que usan la nube, con certificaciones, herramientas especializadas y comunidades activas.

![FinOps1](../x-assets/MF0493/finops1.png)

![FinOps2](../x-assets/MF0493/finops2.png)


# React Native

https://snack.expo.dev/
