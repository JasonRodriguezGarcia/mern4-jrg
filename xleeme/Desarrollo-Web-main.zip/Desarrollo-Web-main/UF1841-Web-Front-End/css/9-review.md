1. ¿Cuál es la sintaxis correcta para aplicar una pseudo-clase :hover en CSS?
A) a:hover { color: red; }
B) a.hover { color: red; }
C) a:hover { color: hover; }
D) a { hover: color:red; }

2. ¿Qué pseudo-elemento se utiliza para aplicar estilos al primer carácter de un elemento?
A) ::first-line
B) ::first-letter
C) ::last-letter
D) ::first-block

3. ¿Cuál es la función principal de @keyframes en CSS?
A) Definir el estilo de un contenedor Flexbox.
B) Crear animaciones.
C) Establecer el tamaño de las columnas en CSS Grid.
D) Aplicar pseudo-clases a elementos.


4. En un contenedor Flexbox, ¿qué propiedad se utiliza para cambiar la dirección del eje principal?
A) flex-flow
B) flex-direction
C) direction
D) align-direction

5. ¿Cuál es la ventaja de utilizar :root en CSS para definir variables?
A) Las variables definidas en :root son accesibles desde cualquier parte del documento.
B) :root solo se aplica a los elementos de nivel superior.
C) No se pueden definir variables dentro de :root.
D) Las variables definidas en :root solo se pueden utilizar en su bloque específico.

6. ¿Cómo se define una clase en CSS?
A) .mi-clase { color: blue; }
B) #mi-clase { color: blue; }
C) mi-clase { color: blue; }
D) :mi-clase { color: blue; }