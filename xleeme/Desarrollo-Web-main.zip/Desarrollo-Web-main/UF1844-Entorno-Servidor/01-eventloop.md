TO DO

https://dev.to/nodedoctors/an-animated-guide-to-nodejs-event-loop-3g62