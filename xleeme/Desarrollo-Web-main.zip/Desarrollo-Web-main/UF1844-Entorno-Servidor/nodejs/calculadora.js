// Declarar
let num1 = 5;
let num2 = 3;

// Sumar
let sum = num1 + num2;
console.log("La suma de " + num1 + " y " + num2 + " es: " + sum);
console.log(`La suma de ${num1} y ${num2} es: ${sum}`);

// Restar
let difference = num1 - num2;
console.log("La diferencia entre " + num1 + " y " + num2 + " es: " + difference);

// Multiplicar
let product = num1 * num2;
console.log("Multiplicando " + num1 + " y " + num2 + " es: " + product);

// Dividir
let div = num1 / num2;
console.log("Dividiendo " + num1 + " por " + num2 + " es: " + div);
